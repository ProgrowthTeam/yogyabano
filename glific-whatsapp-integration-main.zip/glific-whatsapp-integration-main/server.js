//using express, create a normal server

import express from 'express';
import { handler } from './index.js';
const app = express();
const port = 3000;

app.use(express.json());

app.post('/', async (req, res) => {
    try {
        const backFromOpenAI = await handler(req);
        console.log('backFromOpenAI :', backFromOpenAI);
        console.log('Lambda function executed successfully! - from server.js');
        res.send(backFromOpenAI);
    } catch (error) {
        res.send(error);
    }
}
);

//start the server
app.listen(port, () => {
    console.log(`Server started on http://localhost:${port}`);
});