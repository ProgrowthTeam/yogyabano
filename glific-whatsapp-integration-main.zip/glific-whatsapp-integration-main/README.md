# To run the project (supported only for local):
steps : 
- `npm i`

- install ngrok on your system
- create a profile on ngrok

- authorize your local ngrok with the auth token provided on the website
- in the local terminal now use the following cmds
`npm run start`
`ngrok http 3000`

- go to the glific webhook here : https://yogyabano.glific.com/flow/configure/2288442c-e1aa-4b92-94a0-a79b764e370f
- change the post method url to the one given by ngrok in your terminal

Now everything is setup and ready to use


the .zip file is the current version of this code stored on lambda here : https://ap-south-1.console.aws.amazon.com/lambda/home?region=ap-south-1#/functions/whatsapp-bot-glific?tab=code
