import { OpenAI } from 'openai';
import { Pinecone } from '@pinecone-database/pinecone';

import dotenv from 'dotenv';
dotenv.config();

//instanciate openai and pinecone
const openai = new OpenAI({
    apiKey: process.env.OPEN_AI_API_KEY,
});

const pinecone = new Pinecone({
    apiKey: process.env.PINECONE_API_KEY,
});

const runScript = async (reqBody) => {
    try {
      const { message } = reqBody;
      console.log('message recieved from User :', message);
  
      // Process the message and generate a response
      const embedding = await openai.embeddings.create({
          model: "text-embedding-ada-002",
          input: [message],
          encoding_format: "float",
        });
      console.log('Embeddings done');
  
      //send this to pinecone
      const pineconeRAG = await pinecone.Index(process.env.PINECONE_DATABASE_NAME).query(
          {
              vector: embedding.data[0].embedding,
              topK: 1,
          }
      );
      console.log('PineconeRAG done');
      const pineconeResult = pineconeRAG.matches.map((match) => match.metadata).join('\n'); 
      console.log('PineconeRAG :', pineconeResult);
      const prompt = `Based on the following data:\n${pineconeResult}\nGenerate a response to the query.`;
  
      //send this pineconeRAG to openai to get the response
      const responseFromAI = await openai.chat.completions.create({
          messages: [{ role: "user", content: prompt }],
          model: "gpt-4o",
          max_tokens: 150,
        });
      console.log("OpenAi Response recieved");
      return responseFromAI.choices[0].message.content;
    } catch (error) {
      //throw error in case of any error
      throw error;
    }
}

//entry point for lambda function
//when uploading to lambda, this function will be called so remove server.js
export const handler = async (event) => {
  try {
    // Your Lambda function logic goes here
    //use JSON.parse to convert the string to JSON object when using it with lambda
    const backFromOpenAI = await runScript(event.body);
    console.log('Lambda function executed successfully! - from index.js');
    return {
      statusCode: 200,
      response: backFromOpenAI,
    };
  }
  catch (err) {
    console.log('Error executing Lambda function!', err);
    return {
      statusCode: 400,
      body: JSON.stringify({ message: "Some error occured" }),
    };
  }
};